var searchData=
[
  ['vector_20absolute_20value',['Vector Absolute Value',['../group___basic_abs.html',1,'']]],
  ['vector_20addition',['Vector Addition',['../group___basic_add.html',1,'']]],
  ['vector_20multiplication',['Vector Multiplication',['../group___basic_mult.html',1,'']]],
  ['vector_20subtraction',['Vector Subtraction',['../group___basic_sub.html',1,'']]],
  ['vector_20clarke_20transform',['Vector Clarke Transform',['../group__clarke.html',1,'']]],
  ['vector_20copy',['Vector Copy',['../group__copy.html',1,'']]],
  ['vector_20dot_20product',['Vector Dot Product',['../group__dot__prod.html',1,'']]],
  ['vector_20fill',['Vector Fill',['../group___fill.html',1,'']]],
  ['vector_20inverse_20clarke_20transform',['Vector Inverse Clarke Transform',['../group__inv__clarke.html',1,'']]],
  ['vector_20inverse_20park_20transform',['Vector Inverse Park transform',['../group__inv__park.html',1,'']]],
  ['vector_20negate',['Vector Negate',['../group__negate.html',1,'']]],
  ['vector_20offset',['Vector Offset',['../group__offset.html',1,'']]],
  ['vector_20park_20transform',['Vector Park Transform',['../group__park.html',1,'']]],
  ['vector_20scale',['Vector Scale',['../group__scale.html',1,'']]],
  ['vector_20shift',['Vector Shift',['../group__shift.html',1,'']]],
  ['variance',['Variance',['../group__variance.html',1,'']]],
  ['variance_20example',['Variance Example',['../group___variance_example.html',1,'']]]
];
