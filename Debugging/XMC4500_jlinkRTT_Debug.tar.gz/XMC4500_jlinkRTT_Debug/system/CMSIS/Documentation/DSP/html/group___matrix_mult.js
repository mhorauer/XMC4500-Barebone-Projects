var group___matrix_mult =
[
    [ "arm_mat_mult_f32", "group___matrix_mult.html#ga917bf0270310c1d3f0eda1fc7c0026a0", null ],
    [ "arm_mat_mult_fast_q15", "group___matrix_mult.html#ga08f37d93a5bfef0c5000dc5e0a411f93", null ],
    [ "arm_mat_mult_fast_q31", "group___matrix_mult.html#ga2785e8c1b785348b0c439b56aaf585a3", null ],
    [ "arm_mat_mult_q15", "group___matrix_mult.html#ga3657b99a9667945373e520dbac0f4516", null ],
    [ "arm_mat_mult_q31", "group___matrix_mult.html#ga2ec612a8c2c4916477fb9bc1ab548a6e", null ]
];