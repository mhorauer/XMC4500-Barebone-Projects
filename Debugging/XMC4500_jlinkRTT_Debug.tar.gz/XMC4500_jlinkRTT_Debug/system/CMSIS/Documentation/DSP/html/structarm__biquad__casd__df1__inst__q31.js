var structarm__biquad__casd__df1__inst__q31 =
[
    [ "numStages", "structarm__biquad__casd__df1__inst__q31.html#a2c2b579f1df1d8273a5d9d945c27e1b2", null ],
    [ "pCoeffs", "structarm__biquad__casd__df1__inst__q31.html#aa62366c632f3b5305086f841f079dbd2", null ],
    [ "postShift", "structarm__biquad__casd__df1__inst__q31.html#a636c7fbe09ec4bef0bc0a4b4e2151cbe", null ],
    [ "pState", "structarm__biquad__casd__df1__inst__q31.html#a5dcf4727f58eb4e8e8b392508d8657bb", null ]
];