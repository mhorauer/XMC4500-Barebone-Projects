var structarm__cfft__radix2__instance__q15 =
[
    [ "bitReverseFlag", "structarm__cfft__radix2__instance__q15.html#af8300c1f60caa21e6b44b9240ab5af19", null ],
    [ "bitRevFactor", "structarm__cfft__radix2__instance__q15.html#a8722720c542cabd41df83fe88ef4f4cb", null ],
    [ "fftLen", "structarm__cfft__radix2__instance__q15.html#a874085647351dcf3f0de39d2b1d49744", null ],
    [ "ifftFlag", "structarm__cfft__radix2__instance__q15.html#ab5c073286bdd2f6e2bf783ced36bf1de", null ],
    [ "pBitRevTable", "structarm__cfft__radix2__instance__q15.html#ab88afeff6493be3c8b5e4530efa82d51", null ],
    [ "pTwiddle", "structarm__cfft__radix2__instance__q15.html#a3809dd15e7cbf1a054c728cfbbb0cc5a", null ],
    [ "twidCoefModifier", "structarm__cfft__radix2__instance__q15.html#a6f2ab87fb4c568656e1f92f687b5c850", null ]
];