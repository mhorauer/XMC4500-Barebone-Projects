var group___l_m_s___n_o_r_m =
[
    [ "arm_lms_norm_f32", "group___l_m_s___n_o_r_m.html#ga2418c929087c6eba719758eaae3f3300", null ],
    [ "arm_lms_norm_init_f32", "group___l_m_s___n_o_r_m.html#gac7ccbaea863882056eee815456464670", null ],
    [ "arm_lms_norm_init_q15", "group___l_m_s___n_o_r_m.html#ga213ab1ee2e154cc2fa30d667b1994b89", null ],
    [ "arm_lms_norm_init_q31", "group___l_m_s___n_o_r_m.html#ga1d9659dbbea4c89a7a9d14d5fc0dd490", null ],
    [ "arm_lms_norm_q15", "group___l_m_s___n_o_r_m.html#gad47486a399dedb0bc85a5990ec5cf981", null ],
    [ "arm_lms_norm_q31", "group___l_m_s___n_o_r_m.html#ga7128775e99817c183a7d7ad34e8b6e05", null ]
];