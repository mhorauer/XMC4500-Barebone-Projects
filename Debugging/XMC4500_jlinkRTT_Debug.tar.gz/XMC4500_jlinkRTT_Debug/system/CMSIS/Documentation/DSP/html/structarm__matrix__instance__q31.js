var structarm__matrix__instance__q31 =
[
    [ "numCols", "structarm__matrix__instance__q31.html#abd161da7614eda927157f18b698074b1", null ],
    [ "numRows", "structarm__matrix__instance__q31.html#a63bacac158a821c8cfc06088d251598c", null ],
    [ "pData", "structarm__matrix__instance__q31.html#a09a64267c0579fef086efc9059741e56", null ]
];