var searchData=
[
  ['q15_5ft',['q15_t',['../arm__math_8h.html#ab5a8fb21a5b3b983d5f54f31614052ea',1,'arm_math.h']]],
  ['q31_5ft',['q31_t',['../arm__math_8h.html#adc89a3547f5324b7b3b95adec3806bc0',1,'arm_math.h']]],
  ['q63_5ft',['q63_t',['../arm__math_8h.html#a5aea1cb12fc02d9d44c8abf217eaa5c6',1,'arm_math.h']]],
  ['q7_5ft',['q7_t',['../arm__math_8h.html#ae541b6f232c305361e9b416fc9eed263',1,'arm_math.h']]]
];
