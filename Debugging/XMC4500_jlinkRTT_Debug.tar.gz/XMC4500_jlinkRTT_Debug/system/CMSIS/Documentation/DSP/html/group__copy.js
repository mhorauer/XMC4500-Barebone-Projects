var group__copy =
[
    [ "arm_copy_f32", "group__copy.html#gadd1f737e677e0e6ca31767c7001417b3", null ],
    [ "arm_copy_q15", "group__copy.html#ga872ca4cfc18c680b8991ccd569a5fda0", null ],
    [ "arm_copy_q31", "group__copy.html#gaddf70be7e3f87e535c324862b501f3f9", null ],
    [ "arm_copy_q7", "group__copy.html#ga467579beda492aa92797529d794c88fb", null ]
];