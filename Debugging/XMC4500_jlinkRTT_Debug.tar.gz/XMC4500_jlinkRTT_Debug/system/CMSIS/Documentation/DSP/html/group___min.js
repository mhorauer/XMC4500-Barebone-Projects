var group___min =
[
    [ "arm_min_f32", "group___min.html#gaf62b1673740fc516ea64daf777b7d74a", null ],
    [ "arm_min_q15", "group___min.html#gad065e37535ebb726750ac1545cb3fa6f", null ],
    [ "arm_min_q31", "group___min.html#gab20faeceb5ff5d2d9dd628c2ecf41303", null ],
    [ "arm_min_q7", "group___min.html#ga3631d38ac8d715fc14f6f1b343f4c4ed", null ]
];