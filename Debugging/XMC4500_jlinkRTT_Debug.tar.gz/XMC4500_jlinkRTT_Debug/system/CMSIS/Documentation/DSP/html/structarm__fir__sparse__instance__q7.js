var structarm__fir__sparse__instance__q7 =
[
    [ "maxDelay", "structarm__fir__sparse__instance__q7.html#af74dacc1d34c078283e50f2530eb91df", null ],
    [ "numTaps", "structarm__fir__sparse__instance__q7.html#a54cdd27ca1c672b126c38763ce678b1c", null ],
    [ "pCoeffs", "structarm__fir__sparse__instance__q7.html#a3dac86f15e33553e8f3e19e0d712bae5", null ],
    [ "pState", "structarm__fir__sparse__instance__q7.html#a18072cf3ef3666d588f0d49512f2b28f", null ],
    [ "pTapDelay", "structarm__fir__sparse__instance__q7.html#ac625393c84bc0342ffdf26fc4eba1ac1", null ],
    [ "stateIndex", "structarm__fir__sparse__instance__q7.html#a2d2e65473fe3a3f2b953b4e0b60824df", null ]
];