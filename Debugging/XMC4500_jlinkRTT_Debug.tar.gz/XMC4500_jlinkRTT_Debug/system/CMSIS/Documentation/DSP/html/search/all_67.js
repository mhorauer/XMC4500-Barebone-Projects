var searchData=
[
  ['gaindb',['gainDB',['../arm__graphic__equalizer__example__q31_8c.html#a963aee85bb41a50fc943ac9048d123ab',1,'arm_graphic_equalizer_example_q31.c']]],
  ['graphic_20audio_20equalizer_20example',['Graphic Audio Equalizer Example',['../group___g_e_q5_band.html',1,'']]],
  ['getinput',['getinput',['../arm__signal__converge__example__f32_8c.html#afd2975c4763ec935771e6f63bfe7758b',1,'arm_signal_converge_example_f32.c']]]
];
