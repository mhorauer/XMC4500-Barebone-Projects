var searchData=
[
  ['matrix_20functions',['Matrix Functions',['../group__group_matrix.html',1,'']]],
  ['matrix_20addition',['Matrix Addition',['../group___matrix_add.html',1,'']]],
  ['matrix_20example',['Matrix Example',['../group___matrix_example.html',1,'']]],
  ['matrix_20initialization',['Matrix Initialization',['../group___matrix_init.html',1,'']]],
  ['matrix_20inverse',['Matrix Inverse',['../group___matrix_inv.html',1,'']]],
  ['matrix_20multiplication',['Matrix Multiplication',['../group___matrix_mult.html',1,'']]],
  ['matrix_20scale',['Matrix Scale',['../group___matrix_scale.html',1,'']]],
  ['matrix_20subtraction',['Matrix Subtraction',['../group___matrix_sub.html',1,'']]],
  ['matrix_20transpose',['Matrix Transpose',['../group___matrix_trans.html',1,'']]],
  ['maximum',['Maximum',['../group___max.html',1,'']]],
  ['mean',['Mean',['../group__mean.html',1,'']]],
  ['minimum',['Minimum',['../group___min.html',1,'']]]
];
