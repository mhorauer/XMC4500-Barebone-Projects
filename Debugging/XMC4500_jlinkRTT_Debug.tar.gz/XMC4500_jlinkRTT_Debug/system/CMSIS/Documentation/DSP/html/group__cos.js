var group__cos =
[
    [ "arm_cos_f32", "group__cos.html#gace15287f9c64b9b4084d1c797d4c49d8", null ],
    [ "arm_cos_q15", "group__cos.html#gadfd60c24def501638c0d5db20f4c869b", null ],
    [ "arm_cos_q31", "group__cos.html#gad80f121949ef885a77d83ab36e002567", null ],
    [ "cosTable", "group__cos.html#gac597d7d00485bea7080b318b4473e83f", null ],
    [ "cosTableQ15", "group__cos.html#ga012ad965e3493ffcc6dd7f9a12569e58", null ],
    [ "cosTableQ31", "group__cos.html#gafe999a5fcf1774a2292220071096b834", null ]
];