var searchData=
[
  ['bilinear_20interpolation',['Bilinear Interpolation',['../group___bilinear_interpolate.html',1,'']]],
  ['biquad_20cascade_20iir_20filters_20using_20direct_20form_20i_20structure',['Biquad Cascade IIR Filters Using Direct Form I Structure',['../group___biquad_cascade_d_f1.html',1,'']]],
  ['biquad_20cascade_20iir_20filters_20using_20a_20direct_20form_20ii_20transposed_20structure',['Biquad Cascade IIR Filters Using a Direct Form II Transposed Structure',['../group___biquad_cascade_d_f2_t.html',1,'']]],
  ['basic_20math_20functions',['Basic Math Functions',['../group__group_math.html',1,'']]]
];
