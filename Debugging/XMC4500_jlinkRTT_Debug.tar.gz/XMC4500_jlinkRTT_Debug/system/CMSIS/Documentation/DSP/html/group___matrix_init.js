var group___matrix_init =
[
    [ "arm_mat_init_f32", "group___matrix_init.html#ga11e3dc41592a6401c13182fef9416a27", null ],
    [ "arm_mat_init_q15", "group___matrix_init.html#ga31a7c2b991803d49719393eb2d53dc26", null ],
    [ "arm_mat_init_q31", "group___matrix_init.html#ga48a5e5d37e1f062cc57fcfaf683343cc", null ]
];