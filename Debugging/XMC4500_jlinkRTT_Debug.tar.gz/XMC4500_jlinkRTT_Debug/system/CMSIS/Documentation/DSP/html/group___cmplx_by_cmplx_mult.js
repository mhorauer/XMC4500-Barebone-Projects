var group___cmplx_by_cmplx_mult =
[
    [ "arm_cmplx_mult_cmplx_f32", "group___cmplx_by_cmplx_mult.html#ga14b47080054a1ba1250a86805be1ff6b", null ],
    [ "arm_cmplx_mult_cmplx_q15", "group___cmplx_by_cmplx_mult.html#ga67e96abfc9c3e30efb70a2ec9d0fe7e8", null ],
    [ "arm_cmplx_mult_cmplx_q31", "group___cmplx_by_cmplx_mult.html#ga1829e50993a90742de225a0ce4213838", null ]
];