var structarm__rfft__instance__q31 =
[
    [ "bitReverseFlagR", "structarm__rfft__instance__q31.html#a3cb90cdc928a88b0203917dcb3dc1b71", null ],
    [ "fftLenBy2", "structarm__rfft__instance__q31.html#a7d1a948bb8a23bf5419bb6f9ef43dd76", null ],
    [ "fftLenReal", "structarm__rfft__instance__q31.html#af777b0cadd5abaf064323692c2e6693b", null ],
    [ "ifftFlagR", "structarm__rfft__instance__q31.html#af5c2615e6cde15524df38fa57ea32d94", null ],
    [ "pCfft", "structarm__rfft__instance__q31.html#ac6bf12707e1985818d161616adf27977", null ],
    [ "pTwiddleAReal", "structarm__rfft__instance__q31.html#a2a0c944e66bab92fcbe19d1c29153250", null ],
    [ "pTwiddleBReal", "structarm__rfft__instance__q31.html#ae5070be4c2e0327e618f5e1f4c5b9d80", null ],
    [ "twidCoefRModifier", "structarm__rfft__instance__q31.html#a6fc90252b579f7c29e01bd279334fc43", null ]
];