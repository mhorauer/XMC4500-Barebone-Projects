var group__variance =
[
    [ "arm_var_f32", "group__variance.html#ga393f26c5a3bfa05624fb8d32232a6d96", null ],
    [ "arm_var_q15", "group__variance.html#ga957b23ddcc2e0883461797ebf8a2cf1f", null ],
    [ "arm_var_q31", "group__variance.html#ga353e4c924e707ab9ee7687d28094a668", null ]
];