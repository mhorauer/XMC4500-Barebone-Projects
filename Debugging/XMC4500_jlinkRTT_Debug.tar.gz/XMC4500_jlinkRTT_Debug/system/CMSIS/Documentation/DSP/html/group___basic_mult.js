var group___basic_mult =
[
    [ "arm_mult_f32", "group___basic_mult.html#gaca3f0b8227da431ab29225b88888aa32", null ],
    [ "arm_mult_q15", "group___basic_mult.html#gafb0778d27ed98a2a6f2ecb7d48cc8c75", null ],
    [ "arm_mult_q31", "group___basic_mult.html#ga3528c0f54a0607acc603f0490d3ca6c6", null ],
    [ "arm_mult_q7", "group___basic_mult.html#ga16677275ed83ff0878da531e875c27ef", null ]
];