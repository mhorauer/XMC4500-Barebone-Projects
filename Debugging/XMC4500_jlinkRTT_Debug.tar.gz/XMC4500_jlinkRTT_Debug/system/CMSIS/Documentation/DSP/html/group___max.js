var group___max =
[
    [ "arm_max_f32", "group___max.html#ga5b89d1b04575aeec494f678695fb87d8", null ],
    [ "arm_max_q15", "group___max.html#gac132856c68f4bf2a056eaad5921c7880", null ],
    [ "arm_max_q31", "group___max.html#gaff7cbd4e955382def06724cc4cc85795", null ],
    [ "arm_max_q7", "group___max.html#ga6afd64d381b5c232de59163ebfe71e35", null ]
];