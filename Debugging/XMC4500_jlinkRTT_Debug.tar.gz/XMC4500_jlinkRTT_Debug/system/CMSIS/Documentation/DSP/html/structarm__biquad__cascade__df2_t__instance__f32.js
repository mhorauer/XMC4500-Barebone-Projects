var structarm__biquad__cascade__df2_t__instance__f32 =
[
    [ "numStages", "structarm__biquad__cascade__df2_t__instance__f32.html#a4d17958c33c3d0a905f974bac50f033f", null ],
    [ "pCoeffs", "structarm__biquad__cascade__df2_t__instance__f32.html#a49a24fe1b6ad3b0b26779c32d8d80b2e", null ],
    [ "pState", "structarm__biquad__cascade__df2_t__instance__f32.html#a24d223addfd926a7177088cf2efe76b1", null ]
];