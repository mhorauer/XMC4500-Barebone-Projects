var structarm__bilinear__interp__instance__f32 =
[
    [ "numCols", "structarm__bilinear__interp__instance__f32.html#aede17bebfb1f835b61d71dd813eab3f8", null ],
    [ "numRows", "structarm__bilinear__interp__instance__f32.html#a34f2b17cc57b95011960df9718af6ed6", null ],
    [ "pData", "structarm__bilinear__interp__instance__f32.html#afd1e764591c991c212d56c893efb5ea4", null ]
];