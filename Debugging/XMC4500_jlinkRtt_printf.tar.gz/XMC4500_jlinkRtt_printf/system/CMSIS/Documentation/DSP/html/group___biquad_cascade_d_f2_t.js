var group___biquad_cascade_d_f2_t =
[
    [ "arm_biquad_cascade_df2T_f32", "group___biquad_cascade_d_f2_t.html#ga114f373fbc16a314e9f293c7c7649c7f", null ],
    [ "arm_biquad_cascade_df2T_init_f32", "group___biquad_cascade_d_f2_t.html#ga70eaddf317a4a8bde6bd6a97df67fedd", null ]
];