var structarm__iir__lattice__instance__q15 =
[
    [ "numStages", "structarm__iir__lattice__instance__q15.html#a96fbed313bef01070409fa182d26ba3f", null ],
    [ "pkCoeffs", "structarm__iir__lattice__instance__q15.html#a41c214a1ec38d4a82fae8899d715dd29", null ],
    [ "pState", "structarm__iir__lattice__instance__q15.html#afd0136ab917b529554d93f41a5e04618", null ],
    [ "pvCoeffs", "structarm__iir__lattice__instance__q15.html#a4c4f57f45b223abbe2a9fb727bd2cad9", null ]
];