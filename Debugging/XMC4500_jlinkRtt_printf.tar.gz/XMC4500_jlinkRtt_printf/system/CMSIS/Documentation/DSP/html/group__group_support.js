var group__group_support =
[
    [ "Vector Copy", "group__copy.html", "group__copy" ],
    [ "Vector Fill", "group___fill.html", "group___fill" ],
    [ "Convert 32-bit floating point value", "group__float__to__x.html", "group__float__to__x" ],
    [ "Convert 16-bit Integer value", "group__q15__to__x.html", "group__q15__to__x" ],
    [ "Convert 32-bit Integer value", "group__q31__to__x.html", "group__q31__to__x" ],
    [ "Convert 8-bit Integer value", "group__q7__to__x.html", "group__q7__to__x" ]
];