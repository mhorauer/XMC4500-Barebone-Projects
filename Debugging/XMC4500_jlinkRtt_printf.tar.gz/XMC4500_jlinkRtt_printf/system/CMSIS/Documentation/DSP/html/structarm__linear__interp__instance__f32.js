var structarm__linear__interp__instance__f32 =
[
    [ "nValues", "structarm__linear__interp__instance__f32.html#a95f02a926b16d35359aca5b31e813b11", null ],
    [ "pYData", "structarm__linear__interp__instance__f32.html#ab373001f6afad0850359c344a4d7eee4", null ],
    [ "x1", "structarm__linear__interp__instance__f32.html#a08352dc6ea82fbc0827408e018535481", null ],
    [ "xSpacing", "structarm__linear__interp__instance__f32.html#aa8e2d686b5434a406d390b347b183511", null ]
];