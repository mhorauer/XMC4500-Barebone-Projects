var group___basic_add =
[
    [ "arm_add_f32", "group___basic_add.html#ga6a904a547413b10565dd1d251c6bafbd", null ],
    [ "arm_add_q15", "group___basic_add.html#gabb51285a41f511670bbff62fc0e1bf62", null ],
    [ "arm_add_q31", "group___basic_add.html#ga24d6c3f7f8b9fae4847c0c3f26a39a3b", null ],
    [ "arm_add_q7", "group___basic_add.html#gaed633f415a7840a66861debca2dfb96b", null ]
];