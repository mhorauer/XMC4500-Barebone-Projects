var structarm__bilinear__interp__instance__q15 =
[
    [ "numCols", "structarm__bilinear__interp__instance__q15.html#a7fa8772d01583374ff8ac18205a26a37", null ],
    [ "numRows", "structarm__bilinear__interp__instance__q15.html#a2130ae30a804995a9f5d0e2189e08565", null ],
    [ "pData", "structarm__bilinear__interp__instance__q15.html#a50d75b1316cee3e0dfad6dcc4c9a2954", null ]
];