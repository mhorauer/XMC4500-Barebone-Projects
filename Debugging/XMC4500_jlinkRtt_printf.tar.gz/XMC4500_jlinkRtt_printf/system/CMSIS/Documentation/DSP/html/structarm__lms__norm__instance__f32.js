var structarm__lms__norm__instance__f32 =
[
    [ "energy", "structarm__lms__norm__instance__f32.html#a6a4119e4f39447bbee31b066deafa16f", null ],
    [ "mu", "structarm__lms__norm__instance__f32.html#a84401d3cfc6c40f69c08223cf341b886", null ],
    [ "numTaps", "structarm__lms__norm__instance__f32.html#ac95f8ca3d816524c2070643852fac5e8", null ],
    [ "pCoeffs", "structarm__lms__norm__instance__f32.html#a1ba688d90aba7de003ed4ad8e2e7ddda", null ],
    [ "pState", "structarm__lms__norm__instance__f32.html#a0bc03338687002ed5f2e4a363eb095ec", null ],
    [ "x0", "structarm__lms__norm__instance__f32.html#aec958fe89b164a30f38bcca9f5d96218", null ]
];