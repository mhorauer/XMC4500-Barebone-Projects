var searchData=
[
  ['x0',['x0',['../structarm__lms__norm__instance__f32.html#aec958fe89b164a30f38bcca9f5d96218',1,'arm_lms_norm_instance_f32::x0()'],['../structarm__lms__norm__instance__q31.html#a47c4466d644e0d8ba407995adfa9b917',1,'arm_lms_norm_instance_q31::x0()'],['../structarm__lms__norm__instance__q15.html#a3fc1d6f97d2c6d5324871de6895cb7e9',1,'arm_lms_norm_instance_q15::x0()']]],
  ['x1',['x1',['../structarm__linear__interp__instance__f32.html#a08352dc6ea82fbc0827408e018535481',1,'arm_linear_interp_instance_f32']]],
  ['x_5ff32',['X_f32',['../arm__matrix__example__f32_8c.html#a98c67c0fc0cb5f2df51b21482d31d21c',1,'arm_matrix_example_f32.c']]],
  ['xref_5ff32',['xRef_f32',['../arm__matrix__example__f32_8c.html#a6184758419722fa16bb883097c2f596b',1,'arm_matrix_example_f32.c']]],
  ['xspacing',['xSpacing',['../structarm__linear__interp__instance__f32.html#aa8e2d686b5434a406d390b347b183511',1,'arm_linear_interp_instance_f32::xSpacing()'],['../arm__linear__interp__example__f32_8c.html#a0ecae49cebd837aac53411c8f877503d',1,'XSPACING():&#160;arm_linear_interp_example_f32.c']]]
];
