var structarm__cfft__radix2__instance__q31 =
[
    [ "bitReverseFlag", "structarm__cfft__radix2__instance__q31.html#a6239b8d268285334e88c008c07d68616", null ],
    [ "bitRevFactor", "structarm__cfft__radix2__instance__q31.html#a9d17a87263953fe3559a007512c9f3a4", null ],
    [ "fftLen", "structarm__cfft__radix2__instance__q31.html#a960199f1373a192366878ef279eab00f", null ],
    [ "ifftFlag", "structarm__cfft__radix2__instance__q31.html#a2607378ce64be16698bb8a3b1af8d3c8", null ],
    [ "pBitRevTable", "structarm__cfft__radix2__instance__q31.html#ada8e5264f4b22ff4c621817978994674", null ],
    [ "pTwiddle", "structarm__cfft__radix2__instance__q31.html#a1d5bbe9a991e133f81652a77a7985d23", null ],
    [ "twidCoefModifier", "structarm__cfft__radix2__instance__q31.html#ae63ca9193322cd477970c1d2086407d1", null ]
];