var group___matrix_sub =
[
    [ "arm_mat_sub_f32", "group___matrix_sub.html#gac8b72fb70246ccfee3b372002345732c", null ],
    [ "arm_mat_sub_q15", "group___matrix_sub.html#gaf647776a425b7f9dd0aca3e11d81f02f", null ],
    [ "arm_mat_sub_q31", "group___matrix_sub.html#ga39f42e0e3b7f115fbb909d6ff4e1329d", null ]
];