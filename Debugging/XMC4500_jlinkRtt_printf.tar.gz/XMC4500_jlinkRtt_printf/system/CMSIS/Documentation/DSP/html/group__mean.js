var group__mean =
[
    [ "arm_mean_f32", "group__mean.html#ga74ce08c49ab61e57bd50c3a0ca1fdb2b", null ],
    [ "arm_mean_q15", "group__mean.html#gac882495d5f098819fd3939c1ef7795b3", null ],
    [ "arm_mean_q31", "group__mean.html#gacf2526d8c2d75e486e8f0b0e31877ad0", null ],
    [ "arm_mean_q7", "group__mean.html#gaebc707ee539020357c25da4c75b52eb7", null ]
];