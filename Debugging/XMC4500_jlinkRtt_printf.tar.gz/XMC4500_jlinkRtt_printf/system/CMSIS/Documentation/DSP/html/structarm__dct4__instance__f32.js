var structarm__dct4__instance__f32 =
[
    [ "N", "structarm__dct4__instance__f32.html#a262b29a51c371b46efc89120e31ccf37", null ],
    [ "Nby2", "structarm__dct4__instance__f32.html#adb1ef2739ddbe62e5cdadc47455a4147", null ],
    [ "normalize", "structarm__dct4__instance__f32.html#a61ce8c967b2e998a9c0041cca73cdef8", null ],
    [ "pCfft", "structarm__dct4__instance__f32.html#a018f7860b6e070af533fb7d76c7cdc32", null ],
    [ "pCosFactor", "structarm__dct4__instance__f32.html#a6da1187e070801e011ce5e0582efa861", null ],
    [ "pRfft", "structarm__dct4__instance__f32.html#a978f37fc19add31af243ab5c63ae502f", null ],
    [ "pTwiddle", "structarm__dct4__instance__f32.html#ad13544aafad268588c62e3eb35ae662c", null ]
];