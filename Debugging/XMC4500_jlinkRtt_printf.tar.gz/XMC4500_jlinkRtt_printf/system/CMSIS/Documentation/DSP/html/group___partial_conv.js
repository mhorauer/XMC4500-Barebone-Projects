var group___partial_conv =
[
    [ "arm_conv_partial_f32", "group___partial_conv.html#ga16d10f32072cd79fc5fb6e785df45f5e", null ],
    [ "arm_conv_partial_fast_opt_q15", "group___partial_conv.html#ga3de9c4ddcc7886de25b70d875099a8d9", null ],
    [ "arm_conv_partial_fast_q15", "group___partial_conv.html#ga1e4d43385cb62262a78c6752fe1fafb2", null ],
    [ "arm_conv_partial_fast_q31", "group___partial_conv.html#ga10c5294cda8c4985386f4e3944be7650", null ],
    [ "arm_conv_partial_opt_q15", "group___partial_conv.html#ga834b23b4ade8682beeb55778399101f8", null ],
    [ "arm_conv_partial_opt_q7", "group___partial_conv.html#ga3707e16af1435b215840006a7ab0c98f", null ],
    [ "arm_conv_partial_q15", "group___partial_conv.html#ga209a2a913a0c5e5679c5988da8f46b03", null ],
    [ "arm_conv_partial_q31", "group___partial_conv.html#ga78e73a5f02d103168a09821fb461e77a", null ],
    [ "arm_conv_partial_q7", "group___partial_conv.html#ga8567259fe18396dd972242c41741ebf4", null ]
];