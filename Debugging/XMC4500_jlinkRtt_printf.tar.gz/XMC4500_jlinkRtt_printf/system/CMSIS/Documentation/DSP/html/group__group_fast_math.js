var group__group_fast_math =
[
    [ "Cosine", "group__cos.html", "group__cos" ],
    [ "Sine", "group__sin.html", "group__sin" ],
    [ "Square Root", "group___s_q_r_t.html", "group___s_q_r_t" ]
];