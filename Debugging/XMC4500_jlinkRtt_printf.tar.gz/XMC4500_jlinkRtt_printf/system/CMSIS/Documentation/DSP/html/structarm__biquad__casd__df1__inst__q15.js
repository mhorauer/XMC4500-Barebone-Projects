var structarm__biquad__casd__df1__inst__q15 =
[
    [ "numStages", "structarm__biquad__casd__df1__inst__q15.html#ad6d95e70abcf4ff1300181415ad92153", null ],
    [ "pCoeffs", "structarm__biquad__casd__df1__inst__q15.html#a1edaacdebb5b09d7635bf20c779855fc", null ],
    [ "postShift", "structarm__biquad__casd__df1__inst__q15.html#ada7e9d6269e6ed4eacf8f68729e9832d", null ],
    [ "pState", "structarm__biquad__casd__df1__inst__q15.html#a5481104ef2f8f81360b80b47d69ae932", null ]
];