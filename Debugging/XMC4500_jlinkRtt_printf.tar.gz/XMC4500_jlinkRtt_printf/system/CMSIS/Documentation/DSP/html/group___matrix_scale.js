var group___matrix_scale =
[
    [ "arm_mat_scale_f32", "group___matrix_scale.html#ga9cb4e385b18c9a0b9cbc940c1067ca12", null ],
    [ "arm_mat_scale_q15", "group___matrix_scale.html#ga7521769e2cf1c3d9c4656138cd2ae2ca", null ],
    [ "arm_mat_scale_q31", "group___matrix_scale.html#ga609743821ee81fa8c34c4bcdc1ed9744", null ]
];