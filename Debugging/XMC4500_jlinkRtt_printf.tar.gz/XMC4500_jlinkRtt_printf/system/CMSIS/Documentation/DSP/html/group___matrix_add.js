var group___matrix_add =
[
    [ "arm_mat_add_f32", "group___matrix_add.html#ga04bbf64a5f9c9e57dd1efb26a768aba1", null ],
    [ "arm_mat_add_q15", "group___matrix_add.html#ga147e90b7c12a162735ab8824127a33ee", null ],
    [ "arm_mat_add_q31", "group___matrix_add.html#ga7d9d7d81a0832a17b831aad1e4a5dc16", null ]
];