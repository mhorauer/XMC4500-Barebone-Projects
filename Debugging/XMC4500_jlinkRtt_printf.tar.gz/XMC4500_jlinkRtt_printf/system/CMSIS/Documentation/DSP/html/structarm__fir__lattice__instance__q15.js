var structarm__fir__lattice__instance__q15 =
[
    [ "numStages", "structarm__fir__lattice__instance__q15.html#a38b179138d6a6c9cac4f8f79b6fd5357", null ],
    [ "pCoeffs", "structarm__fir__lattice__instance__q15.html#a78f872826140069cf67836fff87360bc", null ],
    [ "pState", "structarm__fir__lattice__instance__q15.html#a37b90dea2bc3ee7c9951a9fe74db0cbb", null ]
];