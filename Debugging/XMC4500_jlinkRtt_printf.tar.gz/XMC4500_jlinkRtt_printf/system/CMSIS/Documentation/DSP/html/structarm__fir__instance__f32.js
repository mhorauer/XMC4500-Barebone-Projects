var structarm__fir__instance__f32 =
[
    [ "numTaps", "structarm__fir__instance__f32.html#a20cf98c92b5323799b7881c9ff4d2f7c", null ],
    [ "pCoeffs", "structarm__fir__instance__f32.html#a1c9cfca901d5902afeb640f2831488f4", null ],
    [ "pState", "structarm__fir__instance__f32.html#a7afcf4022e8560db9b8fd28b0d090a15", null ]
];