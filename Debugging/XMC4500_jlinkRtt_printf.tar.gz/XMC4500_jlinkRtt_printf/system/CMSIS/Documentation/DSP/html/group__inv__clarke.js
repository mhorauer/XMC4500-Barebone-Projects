var group__inv__clarke =
[
    [ "arm_inv_clarke_f32", "group__inv__clarke.html#ga137f0396d837477b899ecae89f075a50", null ],
    [ "arm_inv_clarke_q31", "group__inv__clarke.html#ga2d0c60f114f095a2f27442d98781ba02", null ]
];