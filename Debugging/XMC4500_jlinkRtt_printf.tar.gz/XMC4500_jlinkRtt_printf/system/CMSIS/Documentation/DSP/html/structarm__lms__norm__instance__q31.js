var structarm__lms__norm__instance__q31 =
[
    [ "energy", "structarm__lms__norm__instance__q31.html#a3c0ae42869afec8555dc8e3a7ef9b386", null ],
    [ "mu", "structarm__lms__norm__instance__q31.html#ad3dd2a2406e02fdaa7782ba6c3940a64", null ],
    [ "numTaps", "structarm__lms__norm__instance__q31.html#a28e4c085af69c9c3e2e95dacf8004c3e", null ],
    [ "pCoeffs", "structarm__lms__norm__instance__q31.html#a57a64c1ff102d033c1bd05043f1d9955", null ],
    [ "postShift", "structarm__lms__norm__instance__q31.html#a28d7b9e437817f83397e081967e90f3c", null ],
    [ "pState", "structarm__lms__norm__instance__q31.html#a6b25c96cf048b77078d62f4252a01ec4", null ],
    [ "recipTable", "structarm__lms__norm__instance__q31.html#a85836d0907077b9ac660f7bbbaa9d694", null ],
    [ "x0", "structarm__lms__norm__instance__q31.html#a47c4466d644e0d8ba407995adfa9b917", null ]
];