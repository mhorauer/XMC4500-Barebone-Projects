var structarm__fir__interpolate__instance__q15 =
[
    [ "L", "structarm__fir__interpolate__instance__q15.html#a5431bdc079e72a973b51d359f7f13603", null ],
    [ "pCoeffs", "structarm__fir__interpolate__instance__q15.html#a767d91d61d4c0beeddd4325d28d28e24", null ],
    [ "phaseLength", "structarm__fir__interpolate__instance__q15.html#ad5178a02a697a77e0d0e60705d9f0a19", null ],
    [ "pState", "structarm__fir__interpolate__instance__q15.html#a26b864363fa47954248f2590e3a82a3c", null ]
];