var group___sin_cos =
[
    [ "arm_sin_cos_f32", "group___sin_cos.html#ga4420d45c37d58c310ef9ae1b5fe58020", null ],
    [ "arm_sin_cos_q31", "group___sin_cos.html#gae9e4ddebff9d4eb5d0a093e28e0bc504", null ],
    [ "cosTable", "group___sin_cos.html#ga73d46b72b2e2e5c3301adb7a8a7cab5e", null ],
    [ "cosTableQ31", "group___sin_cos.html#gab3ca1fd1431d146c6bde7d39dd7e903d", null ],
    [ "sinTable", "group___sin_cos.html#ga2e70480fd73eae93d51a6e881bb1f2e4", null ],
    [ "sinTableQ31", "group___sin_cos.html#ga77c2ec4c8f210d254ef0fbeea0bdf067", null ]
];