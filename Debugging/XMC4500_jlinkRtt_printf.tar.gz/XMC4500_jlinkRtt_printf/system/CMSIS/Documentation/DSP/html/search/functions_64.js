var searchData=
[
  ['damages',['DAMAGES',['../license_8txt.html#afc8082d353720b09f7f84a3e99b3a915',1,'license.txt']]]
];
