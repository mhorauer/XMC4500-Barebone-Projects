var group__svd___format__gr =
[
    [ "Device Level", "group__svd__xml__device__gr.html", null ],
    [ "Peripherals Level", "group__svd__xml__peripherals__gr.html", null ],
    [ "Registers Level", "group__svd__xml__registers__gr.html", null ],
    [ "Fields Level", "group__svd__xml__fields__gr.html", null ],
    [ "Enumerated Values Level", "group__svd__xml__enum__gr.html", null ]
];