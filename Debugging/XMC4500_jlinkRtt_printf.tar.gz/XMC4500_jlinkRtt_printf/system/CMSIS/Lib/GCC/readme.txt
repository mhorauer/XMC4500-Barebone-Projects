The DSP libraries:
libarm_cortexM4_mathL_2.a
libarm_cortexM4_mathL_1.a
are not updated. These libraries are only provided for compatibility reasons to earlier DAVE versions (3.1.6 or earlier).
These libraries should not be used for new projects
