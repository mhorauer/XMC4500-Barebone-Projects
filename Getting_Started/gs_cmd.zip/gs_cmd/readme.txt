FLASHING
========
arm-none-eabi-gcc -I. -c -fno-common -O0 -mcpu=cortex-m4 -mthumb main.c
arm-none-eabi-ld -Txmc4500-1024.ld -o main.elf main.o
arm-none-eabi-objcopy -Obinary main.elf main.binary

JLinkExe
J-Link> h
J-Link> device xmc4500-1024
Info: Device "XMC4500-1024" selected (1024 KB flash, 64 KB RAM).
[...]
J-Link> loadbin main.bin, 0xC000000
Loading binary file... [/home/<USER>/pfad/zur/main.bin]
Writing bin data into target memory @ 0x08000000.
Info: J-Link: Flash download: Flash programming performed for 0 ranges (0 bytes)
Info: J-Link: Flash download: Total time needed: 0.742s (Prepare: 0.661s, Compare: 0.016s, Erase: 0.000s, Program: 0.000s, Verify: 0.000s, Restore: 0.064s)
J-Link> r
J-Link> g

DEBUGGING
=========
arm-none-eabi-gcc -I. -c -fno-common -O0 -mcpu=cortex-m4 -mthumb main.c -g
arm-none-eabi-ld -Txmc4500-1024.ld -nostartfiles -o main.elf main.o -Map main.map
arm-none-eabi-objcopy -Obinary main.elf main.bin
arm-none-eabi-objdump -S main.elf > main.lst
arm-none-eabi-size main.elf

[in a separate terminal in the same directory]
JLinkGDBServer -Device XMC4500-1024 -if SWD

arm-none-eabi-gdb main.elf -ex "target remote:2331" -ex "monitor halt" -ex "load" -ex "monitor reset"
b main
c
display i
s
s
s
....


